#include "list.h"
#include "ll.h"

#include <stdint.h>
#include <stdlib.h>

struct Elem {
	void* value;
	LL_ENTRY(Elem) entry;
};

LL_HEAD(Objlist, Elem);
LL_GENERATE(Objlist, Elem, entry);

#define LL_HEAD_INITIALIZER_PTR(head)                   \
    { LL_HEAD_INITIALIZER__HEAD(head->ll_head) }

void* CreateList()
{
struct Objlist* list = (struct Objlist*)malloc(sizeof (struct Objlist));
LL_INIT(list);
return list;
}

void* CreateElem(void* obj)
{
    struct Elem* elem = (struct Elem*)malloc(sizeof (struct Elem));
    elem->value = obj;
    LL_INIT_ENTRY(&elem->entry);
    return elem;
}
void ReleaseElem(void* elem)
{
    free(elem);
}

void* GetObject(void* elem)
{
return ((struct Elem*)elem)->value;
}

int PushBack(void* list, void* elem)
{
return LL_PUSH_BACK(Objlist, (struct Objlist*)list, (struct Elem*)elem);
}

int PushFront(void* list, void* elem)
{
return LL_PUSH_FRONT(Objlist, (struct Objlist*)list, (struct Elem*)elem);
}

int InsertBefore(void* list, void* before, void* elem)
{
return LL_INSERT_BEFORE(Objlist, (struct Objlist*)list, (struct Elem*)before,  (struct Elem*)elem);
}

void* GetFirtElem(void* list)
{
return LL_FIRST(Objlist, (struct Objlist*)list);
}

void* GetNextElem(void* list, void* elem)
{
return LL_NEXT(Objlist, (struct Objlist*)list, elem);
}
void EraseElem(void* list, void* elem)
{
LL_UNLINK_NOWAIT(Objlist, (struct Objlist*)list, elem);
}

void* PopFrontElem(void* list)
{
return LL_POP_FRONT_NOWAIT(Objlist, (struct Objlist*)list);
}


void* PopBackElem(void* list)
{
return LL_POP_BACK_NOWAIT(Objlist, (struct Objlist*)list);
}
int IsListEmpty(void* list)
{
    return LL_EMPTY(Objlist, (struct Objlist*)list);
}

int SizeOfList(void* list)
{
    return LL_SIZE(Objlist, (struct Objlist*)list);
}
