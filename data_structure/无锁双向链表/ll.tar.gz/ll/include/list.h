#ifndef _CS_LIST_H_
#define _CS_LIST_H_
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void* CreateList();
int IsListEmpty(void* list);
int SizeOfList(void* list);

void* CreateElem(void* obj);
void ReleaseElem(void* elem);
void* GetObject(void* elem);

int PushBack(void* list, void* elem);
int PushFront(void* list, void* elem);
int InsertBefore(void* list, void* before, void* elem);
void* PopFrontElem(void* list);
void* PopBackElem(void* list);

void EraseElem(void* list, void* elem);
void* GetFirtElem(void* list);
void* GetNextElem(void* list, void* elem);


#ifdef __cplusplus
}
#endif


#endif
