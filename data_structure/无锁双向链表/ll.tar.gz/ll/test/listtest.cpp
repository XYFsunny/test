#include "list.h"
#include "assert.h"
#include <stdio.h>

int
main()
{
	int i;
    void* list = CreateList();
    assert(IsListEmpty(list));
    assert(SizeOfList(list)==0);
    for (i = 0; i < 100; i++)
    {
    void* elem = CreateElem((void*)i);
   // printf("elem:%p\n", elem);
    assert(PushBack(list, elem));
    assert(SizeOfList(list)==i+1);
    }
   
    //void* elem = GetFirtElem(list);
    //printf("firstelem:%p\n", elem);
    //printf("value:%p\n", GetObject(elem));
 
    void* o, *next_o;
	for (i = 0, o = GetFirtElem(list);
	    i < 100;
	    i++, o = next_o) {
		assert(o != NULL);
		assert(GetObject(o) == (void*)i);

		next_o = GetNextElem(list, o);
	}

    void* elem = GetFirtElem(list);
    EraseElem(list, elem);
    ReleaseElem(elem);
    assert(SizeOfList(list)==99);

    elem = PopFrontElem(list);
    i = 1;
    while (elem != NULL)
    {
		assert(GetObject(elem) == (void*)i);
        ReleaseElem(elem);
        assert(SizeOfList(list)==99-i);
        i++;
        elem = PopFrontElem(list);
    }
    assert(IsListEmpty(list));
    assert(SizeOfList(list)==0);
	return 0;
}
