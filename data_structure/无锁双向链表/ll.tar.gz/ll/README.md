ll
==
Lock-free linked list


A lock-free doubly linked list implemented in C.
