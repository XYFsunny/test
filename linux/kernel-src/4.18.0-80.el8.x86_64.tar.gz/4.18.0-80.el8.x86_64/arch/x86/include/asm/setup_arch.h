/* Hook to call BIOS initialisation function */

/* no action for generic */
